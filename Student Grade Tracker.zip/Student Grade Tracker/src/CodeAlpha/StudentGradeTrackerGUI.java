package CodeAlpha;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class StudentGradeTrackerGUI extends JFrame {
    private JTextField nameField, gradeField;
    private JTable table;
    private DefaultTableModel model;
    private JTextArea reportArea;

    public StudentGradeTrackerGUI() {
        setTitle("Student Grade Tracker");
        setSize(1500, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(15, 15));

        //Main Heading (Top)
        JLabel titleLabel = new JLabel(" Enter Student Details", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titleLabel.setForeground(new Color(0, 51, 102));
        add(titleLabel, BorderLayout.NORTH);

        //Center Panel
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setResizeWeight(0.6);

        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));

        //Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 15, 15));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel nameLabel = new JLabel("Enter Student Name  :");
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        inputPanel.add(nameLabel);

        nameField = new JTextField();
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        inputPanel.add(nameField);

        JLabel gradeLabel = new JLabel("Enter Student Grade  :");
        gradeLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        inputPanel.add(gradeLabel);

        gradeField = new JTextField();
        gradeField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        inputPanel.add(gradeField);

        leftPanel.add(inputPanel, BorderLayout.NORTH);

        //Table
        model = new DefaultTableModel(new String[]{"Students Name", "Grade"}, 0);
        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        table.setRowHeight(28);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 18));
        JScrollPane tableScroll = new JScrollPane(table);
        leftPanel.add(tableScroll, BorderLayout.CENTER);

        //Report Panel
        JPanel reportPanel = new JPanel(new BorderLayout(10, 10));
        JLabel reportLabel = new JLabel("Summary Report", JLabel.CENTER);
        reportLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        reportLabel.setForeground(new Color(0, 102, 153));
        reportPanel.add(reportLabel, BorderLayout.NORTH);

        reportArea = new JTextArea();
        reportArea.setFont(new Font("Consolas", Font.PLAIN, 16));
        reportArea.setEditable(false);
        reportArea.setBackground(new Color(245, 245, 245));
        reportArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        reportPanel.add(new JScrollPane(reportArea), BorderLayout.CENTER);

        splitPane.setLeftComponent(leftPanel);
        splitPane.setRightComponent(reportPanel);
        add(splitPane, BorderLayout.CENTER);

        //Buttons Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 20));
        buttonPanel.setBorder(null);

        JButton addButton = createStyledButton("Add Student", new Color(39, 174, 96));
        JButton reportButton = createStyledButton("Show Report", new Color(41, 128, 185));
        JButton clearButton = createStyledButton("Clear All", new Color(192, 57, 43));

        buttonPanel.add(addButton);
        buttonPanel.add(reportButton);
        buttonPanel.add(clearButton);

        add(buttonPanel, BorderLayout.SOUTH);

        //Button Actions
        addButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String grade = gradeField.getText().trim();
            if (!name.isEmpty() && !grade.isEmpty()) {
                model.insertRow(0, new Object[]{name, grade});
                nameField.setText("");
                gradeField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Please enter both Name and Grade!",
                		"Warning", JOptionPane.WARNING_MESSAGE);
            }
        });

        reportButton.addActionListener(e -> showReport());
        clearButton.addActionListener(e -> {
            model.setRowCount(0);
            reportArea.setText("");
        });
    }

    // 🔹 Button Styling with hover + rounded corners
    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(220, 50));
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        button.setContentAreaFilled(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover & Rounded Background
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bgColor.brighter());
                button.setOpaque(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(bgColor);
                button.setOpaque(true);
            }
        });

        button.setBackground(bgColor);
        button.setOpaque(true);
        button.setBorder(BorderFactory.createLineBorder(bgColor.darker(), 2, true));
        return button;
    }

    // 🔹 Show Report Method
    private void showReport() {
        StringBuilder report = new StringBuilder("Student Report\n\n");

        int total = 0, highest = Integer.MIN_VALUE, lowest = Integer.MAX_VALUE;
        int count = model.getRowCount();

        java.util.List<String> highestStudents = new ArrayList<>();
        java.util.List<String> lowestStudents = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            String name = (String) model.getValueAt(i, 0);
            String gradeStr = (String) model.getValueAt(i, 1);

            try {
                int grade = Integer.parseInt(gradeStr);
                total += grade;

                if (grade > highest) {
                    highest = grade;
                    highestStudents.clear();
                    highestStudents.add(name);
                } else if (grade == highest) {
                    highestStudents.add(name);
                }

                if (grade < lowest) {
                    lowest = grade;
                    lowestStudents.clear();
                    lowestStudents.add(name);
                } else if (grade == lowest) {
                    lowestStudents.add(name);
                }

                report.append((i + 1))
                        .append(". ").append(name)
                        .append(" - Grade: ").append(grade)
                        .append("\n");

            } catch (NumberFormatException ex) {
                report.append((i + 1))
                        .append(". ").append(name)
                        .append(" - Grade: ").append(gradeStr)
                        .append("\n");
            }
        }

        if (count > 0) {
            double average = (double) total / count;
            report.append("\n------------------------------\n");
            report.append("Statistics:\n");
            report.append("Average Marks : ").append(String.format("%.2f", average)).append("\n");
            report.append("Highest Marks : ").append(highest).append(" (")
                    .append(String.join(", ", highestStudents)).append(")\n");
            report.append("Lowest Marks  : ").append(lowest).append(" (")
                    .append(String.join(", ", lowestStudents)).append(")\n");
        }

        reportArea.setText(report.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentGradeTrackerGUI().setVisible(true));
    }
}